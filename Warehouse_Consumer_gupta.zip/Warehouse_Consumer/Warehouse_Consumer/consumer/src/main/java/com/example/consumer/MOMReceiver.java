package com.example.consumer;

import jakarta.jms.*;
import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

import java.util.ArrayList;
import java.util.List;

public class MOMReceiver {

    private static String user = ActiveMQConnection.DEFAULT_USER;
    private static String password = ActiveMQConnection.DEFAULT_PASSWORD;
    private static String url = "tcp://localhost:61616";
    private static String subject = "Warehouse";

    public static List<String> receiveMessages() {
        List<String> messages = new ArrayList<>();

        try {
            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(user, password, url);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination destination = session.createQueue(subject);
            MessageConsumer consumer = session.createConsumer(destination);

            while (true) {
                Message message = consumer.receive(1000); // Timeout set to 1 second

                if (message instanceof TextMessage) {
                    TextMessage textMessage = (TextMessage) message;
                    messages.add(textMessage.getText());
                } else if (message == null) {
                    break; // No more messages
                }
            }

            consumer.close();
            session.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return messages;
    }
}
