package com.example.consumer;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;
import java.io.*;

import com.example.consumer.ProductData;


@RestController
@RequestMapping("/warehouse/001")
public class DataController {

    private final RestTemplate restTemplate = new RestTemplate();
    private final String baseUrl = "http://localhost:8080/warehouse/001";

    @GetMapping("/getQueue")
    public ResponseEntity<String> getQueueMessages() {
        List<String> jsonResponse = MOMReceiver.receiveMessages();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String jsonString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonResponse);

            System.out.println("Received messages: " + jsonString);
            return ResponseEntity.ok(jsonString);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Fehler beim Konvertieren in JSON");
        }
    }

    @GetMapping("/data")
    public ResponseEntity<String> getData() {
        String jsonData = fetchDataFromUrl("/data");
        String xmlData = fetchDataFromUrl("/xml");

        WarehouseData warehouseData = parseJsonData(jsonData);
        List<ProductData> xmlList = parseXmlData(xmlData);

        String jsonTableHtml = createTableFromData(warehouseData.getProductData());
        String xmlTableHtml = createTableFromData(xmlList);

        String responseHtml = "<h1>JSON Data</h1>" + jsonTableHtml + "<h1>XML Data</h1>" + xmlTableHtml;
        return ResponseEntity.ok(responseHtml);
    }

    private String fetchDataFromUrl(String endpoint) {
        String apiUrl = baseUrl + endpoint;
        return restTemplate.getForObject(apiUrl, String.class);
    }

    private WarehouseData parseJsonData(String jsonData) {
        WarehouseData warehouseData = null;

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            warehouseData = objectMapper.readValue(jsonData, WarehouseData.class);
        } catch (IOException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        return warehouseData;
    }

    private List<ProductData> parseXmlData(String xmlData) {
        List<ProductData> dataList = new ArrayList<>();

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xmlData)));

            NodeList productDataNodes = document.getElementsByTagName("productData");

            for (int i = 0; i < productDataNodes.getLength(); i++) {
                Node productDataNode = productDataNodes.item(i);
                if (productDataNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element productDataElement = (Element) productDataNode;
                    ProductData productData = new ProductData();
                    productData.setProductId(productDataElement.getElementsByTagName("productId").item(0).getTextContent());
                    productData.setProductName(productDataElement.getElementsByTagName("productName").item(0).getTextContent());
                    productData.setProductCategory(productDataElement.getElementsByTagName("productCategory").item(0).getTextContent());
                    productData.setProductAmount(productDataElement.getElementsByTagName("productAmount").item(0).getTextContent());
                    productData.setProductUnit(productDataElement.getElementsByTagName("productUnit").item(0).getTextContent());
                    dataList.add(productData);
                }
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        return dataList;
    }


    private String createTableFromData(List<ProductData> productDataList) {
        StringBuilder tableHtml = new StringBuilder("<table><thead><tr>");

        // Add table headers here based on your requirements
        tableHtml.append("<th>Product ID</th>");
        tableHtml.append("<th>Product Name</th>");
        tableHtml.append("<th>Product Category</th>");
        tableHtml.append("<th>Product Amount</th>");
        tableHtml.append("<th>Product Unit</th>");

        tableHtml.append("</tr></thead><tbody>");

        if (productDataList != null) {
            for (ProductData product : productDataList) {
                tableHtml.append("<tr>");
                tableHtml.append("<td>").append(product.getProductId()).append("</td>");
                tableHtml.append("<td>").append(product.getProductName()).append("</td>");
                tableHtml.append("<td>").append(product.getProductCategory()).append("</td>");
                tableHtml.append("<td>").append(product.getProductAmount()).append("</td>");
                tableHtml.append("<td>").append(product.getProductUnit()).append("</td>");
                tableHtml.append("</tr>");
            }
        }

        tableHtml.append("</tbody></table>");
        return tableHtml.toString();
    }



}
