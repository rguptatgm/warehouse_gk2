package tradearea;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tradearea.warehouse.MOMReceiver;
import tradearea.warehouse.MOMSender;
import tradearea.warehouse.WarehouseController;
import tradearea.warehouse.WarehouseService;

@SpringBootApplication
public class WarehouseMomApplication implements CommandLineRunner {

	private WarehouseService service;

	public static void main(String[] args) {
		SpringApplication.run(WarehouseMomApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		String flag = new String("receiver");
		for(String arg:args) {
			flag = arg;
		}

		if ( flag.toLowerCase().equals("sender") )
			new MOMSender(WarehouseService.getWarehouseData());
		else
			new MOMReceiver();

	}
}
