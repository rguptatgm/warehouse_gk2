package tradearea.warehouse;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

import jakarta.jms.ConnectionFactory;
import jakarta.jms.Connection;
import jakarta.jms.DeliveryMode;
import jakarta.jms.Destination;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import tradearea.model.WarehouseData;

import com.google.gson.Gson;

public class MOMSender {

    private static String user = ActiveMQConnection.DEFAULT_USER;
    private static String password = ActiveMQConnection.DEFAULT_PASSWORD;

    // Update the URL to point to your localhost
    private static String url = "tcp://localhost:61616"; // Assuming the default ActiveMQ port

    private static String subject = "Warehouse";

    public MOMSender(WarehouseData warehouseData) {

        System.out.println( "Sender started." );

        // Create the connection.
        Session session = null;
        Connection connection = null;
        MessageProducer producer = null;
        Destination destination = null;

        try {

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(user, password, url);
            connection = connectionFactory.createConnection();
            connection.start();

            // Create the session
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            destination = session.createQueue(subject); // Use createQueue for point-to-point communication

            // Create the producer.
            producer = session.createProducer(destination);
            producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            // Convert the WarehouseData object to a JSON string
            Gson gson = new Gson();
            String jsonString = gson.toJson(warehouseData);

            // Create the message
            TextMessage message = session.createTextMessage(jsonString);
            producer.send(message);
            System.out.println(message.getText());

            connection.stop();

        } catch (Exception e) {

            System.out.println("[MessageProducer] Caught: " + e);
            e.printStackTrace();

        } finally {

            try { producer.close(); } catch (Exception e) {}
            try { session.close(); } catch ( Exception e ) {}
            try { connection.close(); } catch ( Exception e ) {}

        }
        System.out.println( "Sender finished." );

    } // end main

}
